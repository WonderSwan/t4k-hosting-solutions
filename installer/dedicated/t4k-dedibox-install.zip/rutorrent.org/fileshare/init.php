<?php

	$theSettings->registerPlugin("fileshare");

?>