<?php

// avaialable upload services scheme
// to use them mark the 'enable' field to true
$services = array(  			
					'1fichier' => array(		'enabled' => true,
									'login' => '',
									'password' => ''), 

					'2shared' => array('enabled' => true),
					'4shared' => array('enabled' => true),
					'bayfiles' => array('enabled' => true),

					'dataport_cz' => array(	'enabled' => true,
									'login' => '',
									'password' => ''), 

					'depositfiles' => array(	'enabled' => true,
									'login' => '',
									'password' => ''), 

					'dl_free_fr' => array('enabled' => true), 

					'filebox' => array(		'enabled' => true,
									'login' => '',
									'password' => ''), 

					'filepost' => array(		'enabled' => true,
									'account' => true,
									'login' => '',
									'password' => ''), 

					'freakshare' => array(	'enabled' => true,
									'login' => '',
									'password' => ''), 

					'hotfile' => array(	'enabled' => true,
									'account' => true,
									'login' => '',
									'password' => ''), 

					'mediafire' => array(	'enabled' => true,
									'login' => '',
									'password' => ''), 

					'megashares' => array(	'enabled' => true,
									'email' => ''),  

					'netload_in' => array(	'enabled' => true,
									'login' => '',
									'password' => ''), 

					'oron' => array(		'enabled' => true,
									'login' => '',
									'password' => '',
									'email' => ''),  

					'rapidshare' => array(	'enabled' => true,
									'account' => true,
									'login' => '',
									'password' => ''), 

					'sendspace' => array('enabled' => true),

					'turbobit' => array(		'enabled' => true,
									'login' => '',
									'password' => ''),

					'uploaded_to' => array(	'enabled' => true,
									'account' => true,
									'login' => '',
									'password' => '')

);



?>