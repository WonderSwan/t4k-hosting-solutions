<?php
require_once( '../../php/util.php' );
include('conf.php');

echo 'theWebUI.VPLAY.stp = '.json_encode($streampath).';',"\n";

?>