<?php

	$theSettings->registerPlugin("mediastream");

?>