﻿/*
 * PLUGIN MEDIAINFO
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";