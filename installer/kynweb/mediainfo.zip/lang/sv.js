﻿/*
 * PLUGIN MEDIAINFO
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.mediainfo		= "Mediainformation";
