﻿/*
 * PLUGIN MEDIAINFO
 *
 * Serbian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";