﻿/*
 * PLUGIN MEDIAINFO
 *
 * Finnish language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";