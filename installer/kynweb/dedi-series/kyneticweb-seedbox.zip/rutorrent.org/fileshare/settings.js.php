<?php
include('conf.php');

echo 'theWebUI.FS.maxlinks = "',$fs['links'], "\";\n";
echo 'theWebUI.FS.downlink = "',$fs['downloadpath'], "\";\n";
echo 'theWebUI.FS.maxdur = "',$fs['duration'], "\";\n";
